<?php

$email_to = "mail@omfg.skanzy.info"; // your email address send TO
$email_from = "test@omfg.skanzy.info"; // your email address send FROM
$email_subject = "Contact form message"; 
$thankyou = "thankyou.htm"; 

?>